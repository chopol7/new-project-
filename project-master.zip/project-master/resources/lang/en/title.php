<?php

return [
    'title'   => 'Module Configuration Tester',
    'start'   => 'Start testing',
    'version' => 'version',
    'docs'    => 'docs',
    'author'  => '@author',
    'submit'  => [
        'runtest' => 'Run Test'
    ]
];
