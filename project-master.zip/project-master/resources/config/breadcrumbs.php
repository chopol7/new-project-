<?php

return [
    'view' => 'antares/foundation::breadcrumbs.bootstrap3',
];
