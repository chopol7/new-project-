<?php

return [
    'p_d_o_exception' => "1.Check connection to database. <br/>2. Contact to support."
];
