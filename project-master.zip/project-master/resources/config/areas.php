<?php

return [
    'areas'   => [
        'administrators' => 'Administrators',
        'users'          => 'Users',
    ],
    'default' => 'administrators'
];
